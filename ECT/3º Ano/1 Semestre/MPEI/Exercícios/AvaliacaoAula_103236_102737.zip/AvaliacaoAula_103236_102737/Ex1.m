% resolvido na folha de teste
